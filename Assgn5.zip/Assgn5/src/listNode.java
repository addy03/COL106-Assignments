public class listNode
{
    node elem;
    listNode next;

    public listNode(node elem)
    {
        this.elem = elem;
        next = null;
    }
}
